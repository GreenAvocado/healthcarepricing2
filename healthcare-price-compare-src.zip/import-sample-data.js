// Import sample data directly in JavaScript
// This script can be run with Node.js directly

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Sample data
const hospitals = [
  {
    hospital_id: 'NYP001',
    legal_name: 'New York-Presbyterian Hospital',
    common_name: 'NY Presbyterian Hospital',
    city: 'New York',
    state: 'NY',
    zip_code: '10065'
  },
  {
    hospital_id: 'MSM001',
    legal_name: 'Mount Sinai Medical Center',
    common_name: 'Mount Sinai Medical Center',
    city: 'New York',
    state: 'NY',
    zip_code: '10029'
  },
  {
    hospital_id: 'NYU001',
    legal_name: 'NYU Langone Hospitals',
    common_name: 'NYU Langone Health',
    city: 'New York',
    state: 'NY',
    zip_code: '10016'
  },
  {
    hospital_id: 'MSK001',
    legal_name: 'Memorial Sloan Kettering Cancer Center',
    common_name: 'Memorial Sloan Kettering',
    city: 'New York',
    state: 'NY',
    zip_code: '10065'
  },
  {
    hospital_id: 'LHH001',
    legal_name: 'Lenox Hill Hospital',
    common_name: 'Lenox Hill Hospital',
    city: 'New York',
    state: 'NY',
    zip_code: '10075'
  }
];

const procedures = [
  {
    code_id: '70551',
    code_type: 'CPT',
    description: 'MRI - Brain without contrast',
    category: 'Diagnostic Imaging'
  },
  {
    code_id: '70552',
    code_type: 'CPT',
    description: 'MRI - Brain with contrast',
    category: 'Diagnostic Imaging'
  },
  {
    code_id: '72141',
    code_type: 'CPT',
    description: 'MRI - Cervical spine without contrast',
    category: 'Diagnostic Imaging'
  },
  {
    code_id: '72148',
    code_type: 'CPT',
    description: 'MRI - Lumbar spine without contrast',
    category: 'Diagnostic Imaging'
  },
  {
    code_id: '73721',
    code_type: 'CPT',
    description: 'MRI - Knee without contrast',
    category: 'Diagnostic Imaging'
  },
  {
    code_id: '71046',
    code_type: 'CPT',
    description: 'X-Ray - Chest, 2 views',
    category: 'Diagnostic Imaging'
  },
  {
    code_id: '74177',
    code_type: 'CPT',
    description: 'CT Scan - Abdomen with contrast',
    category: 'Diagnostic Imaging'
  },
  {
    code_id: '76700',
    code_type: 'CPT',
    description: 'Ultrasound - Abdomen complete',
    category: 'Diagnostic Imaging'
  },
  {
    code_id: '80053',
    code_type: 'CPT',
    description: 'Blood Test - Comprehensive panel',
    category: 'Laboratory'
  },
  {
    code_id: '99213',
    code_type: 'CPT',
    description: 'Office visit - Established patient, moderate complexity',
    category: 'Evaluation & Management'
  }
];

// Helper function to generate random price within a range
const randomPrice = (min, max) => Math.round(Math.random() * (max - min) + min);

// Generate price data for each hospital and procedure combination
const prices = [];

// For each hospital
for (const hospital of hospitals) {
  // For each procedure
  for (const procedure of procedures) {
    // Generate base price
    const basePrice = randomPrice(
      procedure.code_id.startsWith('7') ? 1000 : 100,  // Imaging procedures are more expensive
      procedure.code_id.startsWith('7') ? 4000 : 800
    );
    
    // Calculate other prices based on the base price
    const cashPrice = Math.round(basePrice * 0.5);  // Cash price is typically 50% of standard charge
    const minNegotiated = Math.round(cashPrice * 0.6);  // Min negotiated is typically 60% of cash price
    const maxNegotiated = Math.round(basePrice * 0.7);  // Max negotiated is typically 70% of standard charge
    
    prices.push({
      hospital_id: hospital.hospital_id,
      code_id: procedure.code_id,
      setting: 'Outpatient',
      gross_charge: basePrice,
      discounted_cash_price: cashPrice,
      min_negotiated_charge: minNegotiated,
      max_negotiated_charge: maxNegotiated
    });
  }
}

// Create SQL insert statements
function generateInsertStatements() {
  let sql = '';
  
  // Insert hospitals
  hospitals.forEach(hospital => {
    sql += `INSERT INTO hospitals (hospital_id, legal_name, common_name, city, state, zip_code) VALUES ('${hospital.hospital_id}', '${hospital.legal_name}', '${hospital.common_name}', '${hospital.city}', '${hospital.state}', '${hospital.zip_code}');\n`;
  });
  
  // Insert procedures
  procedures.forEach(procedure => {
    sql += `INSERT OR REPLACE INTO procedure_codes (code_id, code_type, description, category) VALUES ('${procedure.code_id}', '${procedure.code_type}', '${procedure.description}', '${procedure.category}');\n`;
  });
  
  // Insert prices
  prices.forEach(price => {
    sql += `INSERT INTO procedure_prices (hospital_id, code_id, setting, gross_charge, discounted_cash_price, min_negotiated_charge, max_negotiated_charge) VALUES ('${price.hospital_id}', '${price.code_id}', '${price.setting}', ${price.gross_charge}, ${price.discounted_cash_price}, ${price.min_negotiated_charge}, ${price.max_negotiated_charge});\n`;
  });
  
  return sql;
}

// Write SQL to file
const sqlFilePath = path.join(__dirname, 'sample-data.sql');
fs.writeFileSync(sqlFilePath, generateInsertStatements());
console.log(`Generated SQL file at: ${sqlFilePath}`);

// Execute SQL with wrangler
try {
  console.log('Importing sample data into database...');
  execSync(`wrangler d1 execute DB --local --file=${sqlFilePath}`, { stdio: 'inherit' });
  console.log('Sample data imported successfully!');
} catch (error) {
  console.error('Error importing sample data:', error);
  process.exit(1);
}
