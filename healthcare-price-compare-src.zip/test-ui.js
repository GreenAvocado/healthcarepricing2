// Test script for UI components
// Run with: node test-ui.js

async function testUIComponents() {
  console.log('Testing UI components and navigation...');
  
  // List of pages to test
  const pages = [
    '/',
    '/search?query=mri&zip=10001',
    '/procedure/73721',
    '/hospital/010001',
    '/compare?code=73721&hospital=010001&hospital=020002',
    '/about'
  ];
  
  // Test each page
  for (const page of pages) {
    console.log(`\n--- Testing page: ${page} ---`);
    try {
      const response = await fetch(`http://localhost:8788${page}`);
      console.log('Status:', response.status);
      console.log('OK:', response.ok);
      
      // Check if the response is HTML
      const contentType = response.headers.get('content-type');
      console.log('Content-Type:', contentType);
      
      if (contentType && contentType.includes('text/html')) {
        console.log('Page rendered successfully');
      } else {
        console.log('Warning: Response is not HTML');
      }
    } catch (error) {
      console.error(`Error testing page ${page}:`, error);
    }
  }
  
  console.log('\nUI testing completed.');
}

testUIComponents();
