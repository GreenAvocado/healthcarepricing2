// Test script for API endpoints
// Run with: node test-api.js

async function testApiEndpoints() {
  console.log('Testing API endpoints...');
  
  // Test procedures API
  console.log('\n--- Testing /api/procedures endpoint ---');
  try {
    const proceduresResponse = await fetch('http://localhost:8788/api/procedures?query=mri');
    const proceduresData = await proceduresResponse.json();
    console.log('Status:', proceduresResponse.status);
    console.log('Success:', proceduresData.success);
    console.log('Data count:', proceduresData.data?.length || 0);
  } catch (error) {
    console.error('Error testing procedures API:', error);
  }
  
  // Test hospitals API
  console.log('\n--- Testing /api/hospitals endpoint ---');
  try {
    const hospitalsResponse = await fetch('http://localhost:8788/api/hospitals?query=medical');
    const hospitalsData = await hospitalsResponse.json();
    console.log('Status:', hospitalsResponse.status);
    console.log('Success:', hospitalsData.success);
    console.log('Data count:', hospitalsData.data?.length || 0);
  } catch (error) {
    console.error('Error testing hospitals API:', error);
  }
  
  // Test prices API
  console.log('\n--- Testing /api/prices endpoint ---');
  try {
    const pricesResponse = await fetch('http://localhost:8788/api/prices?code_id=73721');
    const pricesData = await pricesResponse.json();
    console.log('Status:', pricesResponse.status);
    console.log('Success:', pricesData.success);
    console.log('Data count:', pricesData.data?.length || 0);
  } catch (error) {
    console.error('Error testing prices API:', error);
  }
  
  // Test compare API
  console.log('\n--- Testing /api/compare endpoint ---');
  try {
    const compareResponse = await fetch('http://localhost:8788/api/compare?code_id=73721&hospital_id=010001&hospital_id=020002');
    const compareData = await compareResponse.json();
    console.log('Status:', compareResponse.status);
    console.log('Success:', compareData.success);
    console.log('Data count:', compareData.data?.length || 0);
  } catch (error) {
    console.error('Error testing compare API:', error);
  }
  
  // Test hospital-prices API
  console.log('\n--- Testing /api/hospital-prices endpoint ---');
  try {
    const hospitalPricesResponse = await fetch('http://localhost:8788/api/hospital-prices?hospital_id=010001');
    const hospitalPricesData = await hospitalPricesResponse.json();
    console.log('Status:', hospitalPricesResponse.status);
    console.log('Success:', hospitalPricesData.success);
    console.log('Data count:', hospitalPricesData.data?.length || 0);
  } catch (error) {
    console.error('Error testing hospital-prices API:', error);
  }
  
  console.log('\nAPI testing completed.');
}

testApiEndpoints();
