// End-to-end test script
// Run with: node test-e2e.js

async function testEndToEnd() {
  console.log('Running end-to-end tests for healthcare price comparison application...');
  
  // Test scenario: Search for a procedure and compare prices
  console.log('\n--- Test Scenario: Search and Compare Workflow ---');
  
  try {
    // Step 1: Search for a procedure
    console.log('Step 1: Search for "MRI" procedure');
    const searchResponse = await fetch('http://localhost:8788/api/procedures?query=mri');
    const searchData = await searchResponse.json();
    
    if (!searchData.success || !searchData.data || searchData.data.length === 0) {
      throw new Error('Search failed or returned no results');
    }
    
    console.log(`Found ${searchData.data.length} procedures matching "MRI"`);
    
    // Step 2: Select first procedure
    const procedure = searchData.data[0];
    console.log(`Step 2: Selected procedure: ${procedure.description} (${procedure.code_id})`);
    
    // Step 3: Get prices for the procedure
    console.log(`Step 3: Getting prices for procedure ${procedure.code_id}`);
    const pricesResponse = await fetch(`http://localhost:8788/api/prices?code_id=${procedure.code_id}`);
    const pricesData = await pricesResponse.json();
    
    if (!pricesData.success || !pricesData.data || pricesData.data.length === 0) {
      throw new Error('Price lookup failed or returned no results');
    }
    
    console.log(`Found ${pricesData.data.length} hospitals with pricing for this procedure`);
    
    // Step 4: Select two hospitals for comparison
    if (pricesData.data.length < 2) {
      console.log('Not enough hospitals for comparison, test partially successful');
      return;
    }
    
    const hospital1 = pricesData.data[0];
    const hospital2 = pricesData.data[1];
    
    console.log(`Step 4: Selected hospitals for comparison: ${hospital1.hospital_name} and ${hospital2.hospital_name}`);
    
    // Step 5: Compare prices
    console.log('Step 5: Comparing prices between selected hospitals');
    const compareResponse = await fetch(`http://localhost:8788/api/compare?code_id=${procedure.code_id}&hospital_id=${hospital1.hospital_id}&hospital_id=${hospital2.hospital_id}`);
    const compareData = await compareResponse.json();
    
    if (!compareData.success || !compareData.data || compareData.data.length === 0) {
      throw new Error('Comparison failed or returned no results');
    }
    
    console.log('Price comparison successful');
    console.log('Hospital 1 price:', compareData.data[0].discounted_cash_price);
    console.log('Hospital 2 price:', compareData.data[1].discounted_cash_price);
    
    // Calculate price difference
    const price1 = compareData.data[0].discounted_cash_price || 0;
    const price2 = compareData.data[1].discounted_cash_price || 0;
    const difference = Math.abs(price1 - price2);
    const percentDifference = ((difference / Math.max(price1, price2)) * 100).toFixed(2);
    
    console.log(`Price difference: $${difference} (${percentDifference}%)`);
    
    console.log('\nEnd-to-end test completed successfully!');
  } catch (error) {
    console.error('End-to-end test failed:', error);
  }
}

testEndToEnd();
