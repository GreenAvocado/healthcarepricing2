// Import sample data script
// Run with: npx tsx import-sample-data.ts

import { importSampleData } from './src/lib/db/sample-data';

async function main() {
  console.log('Starting sample data import...');
  const result = await importSampleData();
  
  if (result.success) {
    console.log('✅ Sample data import completed successfully!');
  } else {
    console.error('❌ Sample data import failed:', result.error);
    process.exit(1);
  }
}

main().catch(error => {
  console.error('Unhandled error during import:', error);
  process.exit(1);
});
