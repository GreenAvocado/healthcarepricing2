// Generate mockup images for UI preview
// This script creates placeholder images for the UI preview HTML

const fs = require('fs');
const path = require('path');

// Function to create a simple SVG with text
function createSVG(filename, title, width = 800, height = 600, bgColor = '#f3f4f6', textColor = '#1e40af') {
  const svg = `
<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
  <rect width="100%" height="100%" fill="${bgColor}"/>
  <rect x="0" y="0" width="100%" height="80" fill="#1e40af"/>
  <text x="20" y="50" font-family="Arial" font-size="24" font-weight="bold" fill="white">HealthcarePriceCompare</text>
  <text x="${width/2}" y="${height/2}" font-family="Arial" font-size="32" font-weight="bold" fill="${textColor}" text-anchor="middle">${title}</text>
  <text x="${width/2}" y="${height/2 + 40}" font-family="Arial" font-size="18" fill="${textColor}" text-anchor="middle">UI Mockup</text>
</svg>
  `;
  
  fs.writeFileSync(filename, svg);
  console.log(`Created ${filename}`);
}

// Create screenshots directory if it doesn't exist
const screenshotsDir = path.join(__dirname, 'screenshots');
if (!fs.existsSync(screenshotsDir)) {
  fs.mkdirSync(screenshotsDir, { recursive: true });
}

// Create mockup images for each page
createSVG(path.join(screenshotsDir, 'homepage.png'), 'Homepage');
createSVG(path.join(screenshotsDir, 'search_page.png'), 'Search Results Page');
createSVG(path.join(screenshotsDir, 'procedure_page.png'), 'Procedure Details Page');
createSVG(path.join(screenshotsDir, 'comparison_page.png'), 'Price Comparison Page');
createSVG(path.join(screenshotsDir, 'hospital_page.png'), 'Hospital Details Page');
createSVG(path.join(screenshotsDir, 'about_page.png'), 'About Page');

console.log('All mockup images created successfully.');
