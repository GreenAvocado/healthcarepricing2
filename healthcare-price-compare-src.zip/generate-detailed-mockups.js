import React from 'react';
import { createCanvas } from 'canvas';
import fs from 'fs';
import path from 'path';

// Function to create a more detailed mockup image
function createDetailedMockup(filename, title, pageType) {
  const width = 1200;
  const height = 900;
  
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  
  // Background
  ctx.fillStyle = '#f3f4f6';
  ctx.fillRect(0, 0, width, height);
  
  // Header
  ctx.fillStyle = '#1e40af';
  ctx.fillRect(0, 0, width, 80);
  
  // Header text
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 28px Arial';
  ctx.fillText('HealthcarePriceCompare', 30, 50);
  
  // Navigation
  ctx.fillStyle = '#ffffff';
  ctx.font = '16px Arial';
  ctx.fillText('Home', width - 300, 50);
  ctx.fillText('Search', width - 230, 50);
  ctx.fillText('About', width - 160, 50);
  ctx.fillText('FAQ', width - 100, 50);
  
  // Page title
  ctx.fillStyle = '#1e3a8a';
  ctx.font = 'bold 32px Arial';
  ctx.fillText(title, 50, 130);
  
  // Page-specific content
  switch(pageType) {
    case 'homepage':
      drawHomepage(ctx, width, height);
      break;
    case 'search':
      drawSearchPage(ctx, width, height);
      break;
    case 'procedure':
      drawProcedurePage(ctx, width, height);
      break;
    case 'comparison':
      drawComparisonPage(ctx, width, height);
      break;
    case 'hospital':
      drawHospitalPage(ctx, width, height);
      break;
    case 'about':
      drawAboutPage(ctx, width, height);
      break;
    default:
      break;
  }
  
  // Footer
  ctx.fillStyle = '#1f2937';
  ctx.fillRect(0, height - 100, width, 100);
  ctx.fillStyle = '#ffffff';
  ctx.font = '16px Arial';
  ctx.fillText('© 2025 HealthcarePriceCompare. All rights reserved.', width/2 - 180, height - 50);
  
  // Save the image
  const buffer = canvas.toBuffer('image/png');
  fs.writeFileSync(filename, buffer);
  console.log(`Created ${filename}`);
}

function drawHomepage(ctx, width, height) {
  // Search box
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(50, 160, width - 100, 200);
  ctx.strokeStyle = '#d1d5db';
  ctx.lineWidth = 2;
  ctx.strokeRect(50, 160, width - 100, 200);
  
  // Search title
  ctx.fillStyle = '#1f2937';
  ctx.font = 'bold 24px Arial';
  ctx.fillText('Find Healthcare Procedure Prices Near You', 100, 200);
  
  // Search inputs
  ctx.fillStyle = '#f3f4f6';
  ctx.fillRect(100, 230, 300, 50);
  ctx.fillRect(420, 230, 500, 50);
  ctx.fillStyle = '#9ca3af';
  ctx.font = '16px Arial';
  ctx.fillText('Enter ZIP Code', 120, 260);
  ctx.fillText('Search for procedure (e.g., MRI, X-Ray, Blood Test)', 440, 260);
  
  // Search button
  ctx.fillStyle = '#2563eb';
  ctx.fillRect(940, 230, 120, 50);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 16px Arial';
  ctx.fillText('Search', 975, 260);
  
  // Featured sections
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(50, 390, width - 100, 150);
  ctx.strokeStyle = '#d1d5db';
  ctx.lineWidth = 1;
  ctx.strokeRect(50, 390, width - 100, 150);
  
  ctx.fillStyle = '#1f2937';
  ctx.font = 'bold 20px Arial';
  ctx.fillText('Why Use HealthcarePriceCompare?', 100, 430);
  
  // Feature points
  ctx.font = '16px Arial';
  ctx.fillText('• Compare prices across multiple hospitals', 100, 470);
  ctx.fillText('• Find the lowest cash prices for procedures', 450, 470);
  ctx.fillText('• See negotiated insurance rates', 100, 500);
  ctx.fillText('• Make informed healthcare decisions', 450, 500);
  
  // Common procedures
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(50, 570, width - 100, 200);
  ctx.strokeStyle = '#d1d5db';
  ctx.lineWidth = 1;
  ctx.strokeRect(50, 570, width - 100, 200);
  
  ctx.fillStyle = '#1f2937';
  ctx.font = 'bold 20px Arial';
  ctx.fillText('Common Procedures', 100, 610);
  
  // Procedure cards
  for (let i = 0; i < 4; i++) {
    ctx.fillStyle = '#f3f4f6';
    ctx.fillRect(100 + i*270, 640, 250, 100);
    ctx.fillStyle = '#1f2937';
    ctx.font = 'bold 16px Arial';
    
    const procedures = ['MRI - Brain', 'X-Ray - Chest', 'Blood Test - Complete', 'CT Scan - Abdomen'];
    ctx.fillText(procedures[i], 120 + i*270, 670);
    
    ctx.fillStyle = '#6b7280';
    ctx.font = '14px Arial';
    ctx.fillText('Average price: $1,200 - $3,500', 120 + i*270, 700);
    
    ctx.fillStyle = '#2563eb';
    ctx.font = '14px Arial';
    ctx.fillText('Compare prices →', 120 + i*270, 720);
  }
}

function drawSearchPage(ctx, width, height) {
  // Search form
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(50, 160, width - 100, 100);
  ctx.strokeStyle = '#d1d5db';
  ctx.lineWidth = 1;
  ctx.strokeRect(50, 160, width - 100, 100);
  
  // Search inputs
  ctx.fillStyle = '#f3f4f6';
  ctx.fillRect(100, 190, 300, 40);
  ctx.fillRect(420, 190, 300, 40);
  ctx.fillStyle = '#000000';
  ctx.font = '16px Arial';
  ctx.fillText('MRI', 120, 215);
  ctx.fillText('10001', 440, 215);
  
  // Search button
  ctx.fillStyle = '#2563eb';
  ctx.fillRect(740, 190, 100, 40);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 16px Arial';
  ctx.fillText('Search', 765, 215);
  
  // Tabs
  ctx.fillStyle = '#2563eb';
  ctx.fillRect(50, 280, 150, 40);
  ctx.fillStyle = '#f3f4f6';
  ctx.fillRect(200, 280, 150, 40);
  
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 16px Arial';
  ctx.fillText('Procedures', 85, 305);
  
  ctx.fillStyle = '#6b7280';
  ctx.font = 'bold 16px Arial';
  ctx.fillText('Hospitals', 235, 305);
  
  // Results container
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(50, 320, width - 100, 450);
  ctx.strokeStyle = '#d1d5db';
  ctx.lineWidth = 1;
  ctx.strokeRect(50, 320, width - 100, 450);
  
  // Results header
  ctx.fillStyle = '#f3f4f6';
  ctx.fillRect(50, 320, width - 100, 50);
  ctx.fillStyle = '#1f2937';
  ctx.font = 'bold 16px Arial';
  ctx.fillText('Procedure', 100, 350);
  ctx.fillText('Code', 500, 350);
  ctx.fillText('Price Range', 700, 350);
  ctx.fillText('Actions', 1000, 350);
  
  // Results rows
  const procedures = [
    'MRI - Brain without contrast', 
    'MRI - Brain with contrast', 
    'MRI - Cervical spine without contrast', 
    'MRI - Lumbar spine without contrast',
    'MRI - Knee without contrast'
  ];
  
  const codes = ['70551', '70552', '72141', '72148', '73721'];
  const prices = ['$400 - $3,200', '$600 - $4,100', '$450 - $3,500', '$500 - $3,800', '$350 - $2,900'];
  
  for (let i = 0; i < 5; i++) {
    const y = 390 + i*60;
    
    ctx.fillStyle = i % 2 === 0 ? '#ffffff' : '#f9fafb';
    ctx.fillRect(50, y - 20, width - 100, 60);
    
    ctx.fillStyle = '#1f2937';
    ctx.font = '16px Arial';
    ctx.fillText(procedures[i], 100, y);
    ctx.fillText(codes[i], 500, y);
    ctx.fillText(prices[i], 700, y);
    
    ctx.fillStyle = '#2563eb';
    ctx.fillRect(1000, y - 15, 100, 30);
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 14px Arial';
    ctx.fillText('View', 1035, y);
  }
}

function drawProcedurePage(ctx, width, height) {
  // Procedure info
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(50, 160, width - 100, 120);
  ctx.strokeStyle = '#d1d5db';
  ctx.lineWidth = 1;
  ctx.strokeRect(50, 160, width - 100, 120);
  
  ctx.fillStyle = '#1f2937';
  ctx.font = 'bold 24px Arial';
  ctx.fillText('MRI - Brain without contrast', 100, 200);
  
  ctx.fillStyle = '#6b7280';
  ctx.font = '16px Arial';
  ctx.fillText('Code: 70551 | Type: CPT | Category: Diagnostic Imaging', 100, 230);
  
  // ZIP filter
  ctx.fillStyle = '#f3f4f6';
  ctx.fillRect(100, 250, 200, 40);
  ctx.fillStyle = '#000000';
  ctx.font = '16px Arial';
  ctx.fillText('ZIP: 10001', 120, 275);
  
  ctx.fillStyle = '#2563eb';
  ctx.fillRect(320, 250, 150, 40);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 14px Arial';
  ctx.fillText('Update Location', 340, 275);
  
  // Price table
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(50, 300, width - 100, 400);
  ctx.strokeStyle = '#d1d5db';
  ctx.lineWidth = 1;
  ctx.strokeRect(50, 300, width - 100, 400);
  
  // Table header
  ctx.fillStyle = '#f3f4f6';
  ctx.fillRect(50, 300, width - 100, 50);
  ctx.fillStyle = '#1f2937';
  ctx.font = 'bold 16px Arial';
  ctx.fillText('Hospital', 100, 330);
  ctx.fillText('Distance', 350, 330);
  ctx.fillText('Standard Charge', 450, 330);
  ctx.fillText('Cash Price', 600, 330);
  ctx.fillText('Min Negotiated', 750, 330);
  ctx.fillText('Compare', 950, 330);
  ctx.fillText('Select', 1050, 330);
  
  // Table rows
  const hospitals = [
    'NY Presbyterian Hospital', 
    'Mount Sinai Medical Center', 
    'NYU Langone Health', 
    'Memorial Sloan Kettering',
    'Lenox Hill Hospital'
  ];
  
  const distances = ['1.2 mi', '2.5 mi', '3.1 mi', '1.8 mi', '2.7 mi'];
  const standardCharges = ['$3,200', '$2,800', '$3,100', '$3,500', '$2,950'];
  const cashPrices = ['$1,600', '$1,400', '$1,550', '$1,750', '$1,475'];
  const minNegotiated = ['$800', '$950', '$875', '$1,100', '$925'];
  
  for (let i = 0; i < 5; i++) {
    const y = 370 + i*60;
    
    ctx.fillStyle = i % 2 === 0 ? '#ffffff' : '#f9fafb';
    ctx.fillRect(50, y - 20, width - 100, 60);
    
    ctx.fillStyle = '#1f2937';
    ctx.font = '16px Arial';
    ctx.fillText(hospitals[i], 100, y);
    ctx.fillText(distances[i], 350, y);
    ctx.fillText(standardCharges[i], 450, y);
    ctx.fillText(cashPrices[i], 600, y);
    ctx.fillText(minNegotiated[i], 750, y);
    
    ctx.fillStyle = '#2563eb';
    ctx.font = '14px Arial';
    ctx.fillText('View', 950, y);
    
    // Checkbox
    ctx.strokeStyle = '#2563eb';
    ctx.lineWidth = 2;
    ctx.strokeRect(1050, y - 15, 20, 20);
    
    if (i < 2) {
      ctx.fillStyle = '#2563eb';
      ctx.fillRect(1052, y - 13, 16, 16);
    }
  }
  
  // Compare button
  ctx.fillStyle = '#2563eb';
  ctx.fillRect(950, 670, 200, 40);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 16px Arial';
  ctx.fillText('Compare Selected (2)', 980, 695);
}

function drawComparisonPage(ctx, width, height) {
  // Comparison info
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(50, 160, width - 100, 100);
  ctx.strokeStyle = '#d1d5db';
  ctx.lineWidth = 1;
  ctx.strokeRect(50, 160, width - 100, 100);
  
  ctx.fillStyle = '#1f2937';
  ctx.font = 'bold 24px Arial';
  ctx.fillText('Price Comparison: MRI - Brain without contrast', 100, 200);
  
  ctx.fillStyle = '#6b7280';
  ctx.font = '16px Arial';
  ctx.fillText('Code: 70551 | Type: CPT | Category: Diagnostic Imaging', 100, 230);
  
  // Price summary cards
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(50, 280, width - 100, 150);
  ctx.strokeStyle = '#d1d5db';
  ctx.lineWidth = 1;
  ctx.strokeRect(50, 280, width - 100, 150);
  
  ctx.fillStyle = '#1f2937';
  ctx.font = 'bold 18px Arial';
  ctx.fillText('Price Summary', 100, 310);
  
  // Cards
  const cardColors = ['#ebf5ff', '#f0fdf4', '#fdf2f8'];
  const cardTitles = ['Price Range (Cash Price)', 'Lowest Cash Price', 'Lowest Insurance Rate'];
  const cardValues = ['$1,400 - $1,600', '$1,400', '$800'];
  const cardSubtexts = ['', 'at Mount Sinai Medical Center', 'at NY Presbyterian Hospital'];
  
  for (let i = 0; i < 3; i++) {
    ctx.fillStyle = cardColors[i];
    ctx.fillRect(100 + i*350, 330, 300, 80);
    
    ctx.fillStyle = '#6b7280';
    ctx.font = '14px Arial';
    ctx.fillText(cardTitles[i], 120 + i*350, 350);
    
    ctx.fillStyle = '#1f2937';
    ctx.font = 'bold 20px Arial';
    ctx.fillText(cardValues[i], 120 + i*350, 380);
    
    ctx.fillStyle = '#6b7280';
    ctx.font = '12px Arial';
    ctx.fillText(cardSubtexts[i], 120 + i*350, 400);
  }
  
  // Comparison table
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(50, 450, width - 100, 250);
  ctx.strokeStyle = '#d1d5db';
  ctx.lineWidth = 1;
  ctx.strokeRect(50, 450, width - 100, 250);
  
  ctx.fillStyle = '#1f2937';
  ctx.font = 'bold 18px Arial';
  ctx.fillText('Detailed Comparison', 100, 480);
  
  // Table header
  ctx.fillStyle = '#f3f4f6';
  ctx.fillRect(50, 500, width - 100, 40);
  ctx.fillStyle = '#1f2937';
  ctx.font = 'bold 14px Arial';
  ctx.fillText('Hospital', 100, 525);
  ctx.fillText('Standard Charge', 350, 525);
  ctx.fillText('Cash Price', 500, 525);
  ctx.fillText('Min Negotiated', 650, 525);
  ctx.fillText('Max Negotiated', 800, 525);
  ctx.fillText('Savings vs Highest', 950, 525);
  
  // Table rows
  const hospitals = ['NY Presbyterian Hospital', 'Mount Sinai Medical Center'];
  const standardCharges = ['$3,200', '$2,800'];
  const cashPrices = ['$1,600', '$1,400'];
  const minNegotiated = ['$800', '$950'];
  const maxNegotiated = ['$2,100', '$1,900'];
  const savings = ['-', '$200 (12.5%)'];
  
  for (let i = 0; i < 2; i++) {
    const y = 565 + i*60;
    
    ctx.fillStyle = i === 1 ? '#f0fdf4' : '#ffffff';
    ctx.fillRect(50, y - 20, width - 100, 60);
    
    ctx.fillStyle = '#1f2937';
    ctx.font = '16px Arial';
    ctx.fillText(hospitals[i], 100, y);
    ctx.fillText(standardCharges[i], 350, y);
    ctx.fillText(cashPrices[i], 500, y);
    ctx.fillText(minNegotiated[i], 650, y);
    ctx.fillText(maxNegotiated[i], 800, y);
    
    if (i === 1) {
      ctx.fillStyle = '#059669';
      ctx.fillText(savings[i], 950, y);
      
      // Lowest price badge
      ctx.fillStyle = '#d1fae5';
      ctx.fillRect(250, y - 15, 80, 20);
      ctx.fillStyle = '#059669';
      ctx.font = 'bold 12px Arial';
      ctx.fillText('Lowest Price', 255, y - 2);
    } else {
      ctx.fillStyle = '#6b7280';
      ctx.fillText(savings[i], 950, y);
    }
  }
}

function drawHospitalPage(ctx, width, height) {
  // Hospital info
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(50, 160, width - 100, 150);
  ctx.strokeStyle = '#d1d5db';
  ctx.lineWidth = 1;
  ctx.strokeRect(50, 160, width - 100, 150);
  
  ctx.fillStyle = '#1f2937';
  ctx.font = 'bold 24px Arial';
  ctx.fillText('Mount Sinai Medical Center', 100, 200);
  
  // Hospital details
  ctx.fillStyle = '#6b7280';
  ctx.font = 'bold 16px Arial';
  ctx.fillText('Hospital ID:', 100, 240);
  ctx.fillText('Location:', 100, 270);
  ctx.fillText('Available Procedures:', 100, 300);
  
  ctx.fillStyle = '#1f2937';
  ctx.font = '16px Arial';
  ctx.fillText('020001', 200, 240);
  ctx.fillText('New York, NY 10029', 200, 270);
  ctx.fillText('1,245', 250, 300);
  
  // Procedure search
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(50, 330, width - 100, 100);
  ctx.strokeStyle = '#d1d5db';
  ctx.lineWidth = 1;
  ctx.strokeRect(50, 330, width - 100, 100);
  
  ctx.fillStyle = '#1f2937';
  ctx.font = 'bold 18px Arial';
  ctx.fillText('Procedure Prices', 100, 360);
  
  ctx.fillStyle = '#6b7280';
  ctx.font = '16px Arial';
  ctx.fillText('Search and browse prices for procedures available at this hospital.', 100, 390);
  
  // Search box
  ctx.fillStyle = '#f3f4f6';
  ctx.fillRect(100, 410, 500, 40);
  ctx.fillStyle = '#9ca3af';
  ctx.font = '16px Arial';
  ctx.fillText('Search by procedure name or code', 120, 435);
  
  // Procedure table
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(50, 450, width - 100, 300);
  ctx.strokeStyle = '#d1d5db';
  ctx.lineWidth = 1;
  ctx.strokeRect(50, 450, width - 100, 300);
  
  // Table header
  ctx.fillStyle = '#f3f4f6';
  ctx.fillRect(50, 450, width - 100, 50);
  ctx.fillStyle = '#1f2937';
  ctx.font = 'bold 16px Arial';
  ctx.fillText('Procedure', 100, 480);
  ctx.fillText('Code', 400, 480);
  ctx.fillText('Standard Charge', 500, 480);
  ctx.fillText('Cash Price', 650, 480);
  ctx.fillText('Min Negotiated', 800, 480);
  ctx.fillText('Compare', 950, 480);
  
  // Table rows
  const procedures = [
    'MRI - Brain without contrast', 
    'X-Ray - Chest, 2 views', 
    'CT Scan - Abdomen with contrast', 
    'Ultrasound - Abdomen complete',
    'Blood Test - Comprehensive panel'
  ];
  
  const codes = ['70551', '71046', '74177', '76700', '80053'];
  const standardCharges = ['$2,800', '$420', '$1,900', '$650', '$380'];
  const cashPrices = ['$1,400', '$210', '$950', '$325', '$190'];
  const minNegotiated = ['$950', '$140', '$640', '$220', '$125'];
  
  for (let i = 0; i < 5; i++) {
    const y = 520 + i*50;
    
    ctx.fillStyle = i % 2 === 0 ? '#ffffff' : '#f9fafb';
    ctx.fillRect(50, y - 20, width - 100, 50);
    
    ctx.fillStyle = '#1f2937';
    ctx.font = '16px Arial';
    ctx.fillText(procedures[i], 100, y);
    ctx.fillText(codes[i], 400, y);
    ctx.fillText(standardCharges[i], 500, y);
    ctx.fillText(cashPrices[i], 650, y);
    ctx.fillText(minNegotiated[i], 800, y);
    
    ctx.fillStyle = '#2563eb';
    ctx.font = '14px Arial';
    ctx.fillText('Compare', 950, y);
  }
}

function drawAboutPage(ctx, width, height) {
  // About content
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(50, 160, width - 100, 600);
  ctx.strokeStyle = '#d1d5db';
  ctx.lineWidth = 1;
  ctx.strokeRect(50, 160, width - 100, 600);
  
  ctx.fillStyle = '#1f2937';
  ctx.font = 'bold 24px Arial';
  ctx.fillText('About HealthcarePriceCompare', 100, 200);
  
  ctx.fillStyle = '#6b7280';
  ctx.font = '16px Arial';
  ctx.fillText('Empowering consumers with healthcare price transparency', 100, 230);
  
  // Content sections
  const sections = [
    {
      title: 'Our Mission',
      content: 'HealthcarePriceCompare was created to help consumers make informed decisions about their healthcare by providing transparent pricing information. We believe that everyone deserves to know the cost of medical procedures before receiving care.'
    },
    {
      title: 'Hospital Price Transparency',
      content: 'In January 2021, the Centers for Medicare & Medicaid Services (CMS) implemented a hospital price transparency rule requiring hospitals to provide clear, accessible pricing information online about the items and services they provide.'
    },
    {
      title: 'How We Help',
      content: 'Our platform offers several key benefits: price comparison across hospitals, location-based search, comprehensive information on different price points, and a user-friendly interface to understand complex healthcare pricing information.'
    },
    {
      title: 'Understanding Healthcare Prices',
      content: 'Healthcare pricing can be complex. We show different price types: Standard Charge (full list price), Discounted Cash Price (for self-pay patients), and Negotiated Rates (prices negotiated with insurance companies).'
    }
  ];
  
  let yPos = 280;
  
  for (const section of sections) {
    ctx.fillStyle = '#1f2937';
    ctx.font = 'bold 20px Arial';
    ctx.fillText(section.title, 100, yPos);
    
    ctx.fillStyle = '#4b5563';
    ctx.font = '16px Arial';
    
    // Wrap text
    const words = section.content.split(' ');
    let line = '';
    let lineHeight = 24;
    let testY = yPos + 30;
    
    for (let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + ' ';
      const metrics = ctx.measureText(testLine);
      const testWidth = metrics.width;
      
      if (testWidth > width - 250 && n > 0) {
        ctx.fillText(line, 100, testY);
        line = words[n] + ' ';
        testY += lineHeight;
      } else {
        line = testLine;
      }
    }
    
    ctx.fillText(line, 100, testY);
    yPos = testY + 40;
  }
}

// Create screenshots directory if it doesn't exist
const screenshotsDir = './screenshots';
if (!fs.existsSync(screenshotsDir)) {
  fs.mkdirSync(screenshotsDir, { recursive: true });
}

// Create mockup images for each page
createDetailedMockup(path.join(screenshotsDir, 'homepage_detailed.png'), 'Find and Compare Healthcare Prices', 'homepage');
createDetailedMockup(path.join(screenshotsDir, 'search_page_detailed.png'), 'Search Results: MRI', 'search');
createDetailedMockup(path.join(screenshotsDir, 'procedure_page_detailed.png'), 'Procedure: MRI - Brain without contrast', 'procedure');
createDetailedMockup(path.join(screenshotsDir, 'comparison_page_detailed.png'), 'Price Comparison', 'comparison');
createDetailedMockup(path.join(screenshotsDir, 'hospital_page_detailed.png'), 'Hospital Details', 'hospital');
createDetailedMockup(path.join(screenshotsDir, 'about_page_detailed.png'), 'About Us', 'about');

console.log('All detailed mockup images created successfully.');
