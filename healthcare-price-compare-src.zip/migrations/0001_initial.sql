-- Migration number: 0001 	 2025-03-13
-- Hospital Price Transparency Database Schema

-- Drop existing tables if they exist
DROP TABLE IF EXISTS saved_searches;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS drug_prices;
DROP TABLE IF EXISTS negotiated_rates;
DROP TABLE IF EXISTS payer_plans;
DROP TABLE IF EXISTS procedure_prices;
DROP TABLE IF EXISTS procedure_codes;
DROP TABLE IF EXISTS pricing_files;
DROP TABLE IF EXISTS hospitals;

-- Create tables

-- Hospitals table
CREATE TABLE hospitals (
    hospital_id TEXT PRIMARY KEY,  -- CCN (CMS Certification Number)
    legal_name TEXT NOT NULL,
    common_name TEXT,
    address TEXT,
    city TEXT,
    state TEXT,
    zip_code TEXT,
    latitude REAL,
    longitude REAL,
    website_url TEXT,
    phone TEXT,
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- PricingFiles table
CREATE TABLE pricing_files (
    file_id INTEGER PRIMARY KEY AUTOINCREMENT,
    hospital_id TEXT,
    file_url TEXT,
    file_format TEXT,  -- CSV, JSON, XML, etc.
    file_size INTEGER,
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
    status TEXT,  -- active, archived, error
    notes TEXT,
    FOREIGN KEY (hospital_id) REFERENCES hospitals(hospital_id)
);

-- ProcedureCodes table
CREATE TABLE procedure_codes (
    code_id TEXT PRIMARY KEY,
    code_type TEXT,  -- CPT, HCPCS, DRG, etc.
    description TEXT,
    category TEXT,
    subcategory TEXT
);

-- ProcedurePrices table
CREATE TABLE procedure_prices (
    price_id INTEGER PRIMARY KEY AUTOINCREMENT,
    hospital_id TEXT,
    code_id TEXT,
    setting TEXT,  -- inpatient, outpatient, both
    gross_charge REAL,  -- standard charge
    discounted_cash_price REAL,  -- self-pay discount
    min_negotiated_charge REAL,  -- de-identified minimum
    max_negotiated_charge REAL,  -- de-identified maximum
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (hospital_id) REFERENCES hospitals(hospital_id),
    FOREIGN KEY (code_id) REFERENCES procedure_codes(code_id)
);

-- PayerPlans table
CREATE TABLE payer_plans (
    plan_id INTEGER PRIMARY KEY AUTOINCREMENT,
    payer_name TEXT,
    plan_name TEXT,
    plan_type TEXT  -- HMO, PPO, EPO, etc.
);

-- NegotiatedRates table
CREATE TABLE negotiated_rates (
    rate_id INTEGER PRIMARY KEY AUTOINCREMENT,
    hospital_id TEXT,
    code_id TEXT,
    plan_id INTEGER,
    negotiated_rate REAL,
    negotiated_percentage REAL,
    negotiated_algorithm TEXT,
    additional_notes TEXT,
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (hospital_id) REFERENCES hospitals(hospital_id),
    FOREIGN KEY (code_id) REFERENCES procedure_codes(code_id),
    FOREIGN KEY (plan_id) REFERENCES payer_plans(plan_id)
);

-- DrugPrices table (for pharmaceutical items)
CREATE TABLE drug_prices (
    drug_price_id INTEGER PRIMARY KEY AUTOINCREMENT,
    hospital_id TEXT,
    ndc_code TEXT,  -- National Drug Code
    drug_name TEXT,
    description TEXT,
    unit_of_measurement TEXT,
    type_of_measurement TEXT,
    gross_charge REAL,
    discounted_cash_price REAL,
    min_negotiated_charge REAL,
    max_negotiated_charge REAL,
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (hospital_id) REFERENCES hospitals(hospital_id)
);

-- Users table (for application users)
CREATE TABLE users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    password_hash TEXT,
    first_name TEXT,
    last_name TEXT,
    zip_code TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_login DATETIME
);

-- SavedSearches table
CREATE TABLE saved_searches (
    search_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    procedure_code TEXT,
    location TEXT,
    radius INTEGER,  -- search radius in miles
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create indexes

-- Hospital location index for geographic searches
CREATE INDEX idx_hospitals_location ON hospitals(state, city, zip_code);

-- Procedure codes index for quick lookups
CREATE INDEX idx_procedure_codes_type ON procedure_codes(code_type, code_id);
CREATE INDEX idx_procedure_codes_category ON procedure_codes(category, subcategory);

-- Price lookup indexes
CREATE INDEX idx_procedure_prices_hospital ON procedure_prices(hospital_id);
CREATE INDEX idx_procedure_prices_code ON procedure_prices(code_id);
CREATE INDEX idx_procedure_prices_setting ON procedure_prices(setting);

-- Negotiated rates indexes
CREATE INDEX idx_negotiated_rates_hospital ON negotiated_rates(hospital_id);
CREATE INDEX idx_negotiated_rates_code ON negotiated_rates(code_id);
CREATE INDEX idx_negotiated_rates_plan ON negotiated_rates(plan_id);

-- Sample data for testing
INSERT INTO hospitals (hospital_id, legal_name, common_name, city, state, zip_code) VALUES 
('010001', 'Sample Hospital Medical Center', 'Sample Hospital', 'New York', 'NY', '10001'),
('020002', 'Example Community Hospital', 'Example Hospital', 'Los Angeles', 'CA', '90001');

INSERT INTO procedure_codes (code_id, code_type, description, category) VALUES 
('99213', 'CPT', 'Office/outpatient visit established patient', 'Evaluation & Management'),
('73721', 'CPT', 'MRI joint of lower extremity', 'Radiology'),
('470', 'DRG', 'Major joint replacement or reattachment of lower extremity without MCC', 'Inpatient');
