'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

interface ProcedurePrice {
  price_id?: number;
  hospital_id: string;
  code_id: string;
  hospital_name: string;
  setting?: string;
  gross_charge?: number;
  discounted_cash_price?: number;
  min_negotiated_charge?: number;
  max_negotiated_charge?: number;
}

export default function ProcedurePage({ 
  params 
}: { 
  params: { code: string } 
}) {
  const [procedureCode, setProcedureCode] = useState<string>(params.code);
  const [procedureDetails, setProcedureDetails] = useState<any>(null);
  const [prices, setPrices] = useState<ProcedurePrice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [selectedHospitals, setSelectedHospitals] = useState<string[]>([]);
  
  useEffect(() => {
    // Get ZIP code from URL if present
    const urlParams = new URLSearchParams(window.location.search);
    const zip = urlParams.get('zip');
    if (zip) {
      setZipCode(zip);
    }
    
    // Load procedure details and prices
    loadProcedureData();
  }, []);
  
  const loadProcedureData = async () => {
    setLoading(true);
    setError('');
    
    try {
      // Get procedure details
      const procedureResponse = await fetch(`/api/procedures?code_id=${procedureCode}`);
      const procedureData = await procedureResponse.json();
      
      if (procedureData.success && procedureData.data.length > 0) {
        setProcedureDetails(procedureData.data[0]);
      }
      
      // Get procedure prices
      const pricesResponse = await fetch(`/api/prices?code_id=${procedureCode}${zipCode ? `&zip_code=${zipCode}` : ''}`);
      const pricesData = await pricesResponse.json();
      
      if (pricesData.success) {
        setPrices(pricesData.data);
      } else {
        setError(pricesData.error || 'Failed to load procedure prices');
      }
    } catch (err) {
      setError('An error occurred while loading procedure data');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  const toggleHospitalSelection = (hospitalId: string) => {
    setSelectedHospitals(prev => {
      if (prev.includes(hospitalId)) {
        return prev.filter(id => id !== hospitalId);
      } else {
        return [...prev, hospitalId];
      }
    });
  };
  
  const formatCurrency = (amount?: number) => {
    if (amount === undefined || amount === null) return 'N/A';
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold text-blue-800">HealthcarePriceCompare</Link>
          <nav className="flex space-x-4">
            <Link href="/" className="text-blue-600 hover:text-blue-800">Home</Link>
            <Link href="/search" className="text-blue-600 hover:text-blue-800">Search</Link>
            <Link href="/about" className="text-blue-600 hover:text-blue-800">About</Link>
          </nav>
        </div>
      </header>
      
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {loading ? (
          <div className="text-center py-12">
            <svg className="animate-spin h-8 w-8 text-blue-500 mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <p className="mt-2 text-sm text-gray-500">Loading procedure data...</p>
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <p className="text-red-500">{error}</p>
            <Link href="/search" className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700">
              Back to Search
            </Link>
          </div>
        ) : (
          <div>
            <div className="bg-white shadow overflow-hidden sm:rounded-lg mb-8">
              <div className="px-4 py-5 sm:px-6">
                <h2 className="text-2xl font-bold text-gray-900">
                  {procedureDetails?.description || `Procedure ${procedureCode}`}
                </h2>
                <p className="mt-1 max-w-2xl text-sm text-gray-500">
                  Code: {procedureCode} | Type: {procedureDetails?.code_type || 'Unknown'}
                  {procedureDetails?.category && ` | Category: ${procedureDetails.category}`}
                </p>
              </div>
              
              <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
                <div className="mb-6">
                  <label htmlFor="zip-code" className="block text-sm font-medium text-gray-700">
                    Filter by ZIP Code
                  </label>
                  <div className="mt-1 flex rounded-md shadow-sm">
                    <input
                      type="text"
                      id="zip-code"
                      className="flex-1 min-w-0 block w-full px-3 py-2 rounded-none rounded-l-md border border-gray-300 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                      placeholder="Enter ZIP code"
                      value={zipCode}
                      onChange={(e) => setZipCode(e.target.value)}
                    />
                    <button
                      type="button"
                      className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-r-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                      onClick={loadProcedureData}
                    >
                      Update
                    </button>
                  </div>
                </div>
                
                {prices.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No price data available for this procedure.</p>
                    <p className="text-sm text-gray-400 mt-2">Try searching with a different ZIP code or procedure code.</p>
                  </div>
                ) : (
                  <div>
                    <div className="flex justify-between items-center mb-4">
                      <h3 className="text-lg font-medium text-gray-900">Hospital Prices</h3>
                      {selectedHospitals.length >= 2 && (
                        <Link
                          href={`/compare?code=${procedureCode}&${selectedHospitals.map(id => `hospital=${id}`).join('&')}`}
                          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700"
                        >
                          Compare Selected ({selectedHospitals.length})
                        </Link>
                      )}
                    </div>
                    
                    <div className="flex flex-col">
                      <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                          <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                            <table className="min-w-full divide-y divide-gray-200">
                              <thead className="bg-gray-50">
                                <tr>
                                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Compare
                                  </th>
                                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Hospital
                                  </th>
                                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Standard Charge
                                  </th>
                                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Cash Price
                                  </th>
                                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Min Negotiated
                                  </th>
                                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Max Negotiated
                                  </th>
                                </tr>
                              </thead>
                              <tbody className="bg-white divide-y divide-gray-200">
                                {prices.map((price) => (
                                  <tr key={`${price.hospital_id}-${price.code_id}`}>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                      <input
                                        type="checkbox"
                                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                                        checked={selectedHospitals.includes(price.hospital_id)}
                                        onChange={() => toggleHospitalSelection(price.hospital_id)}
                                      />
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap">
                                      <Link href={`/hospital/${price.hospital_id}`} className="text-blue-600 hover:text-blue-900">
                                        {price.hospital_name}
                                      </Link>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                      {formatCurrency(price.gross_charge)}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                      {formatCurrency(price.discounted_cash_price)}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                      {formatCurrency(price.min_negotiated_charge)}
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                      {formatCurrency(price.max_negotiated_charge)}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            <div className="bg-white shadow overflow-hidden sm:rounded-lg">
              <div className="px-4 py-5 sm:px-6">
                <h3 className="text-lg font-medium text-gray-900">Understanding Healthcare Prices</h3>
              </div>
              <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
                <dl className="grid grid-cols-1 gap-x-4 gap-y-8 sm:grid-cols-2">
                  <div className="sm:col-span-1">
                    <dt className="text-sm font-medium text-gray-500">Standard Charge</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      The hospital's gross charge for the procedure before any discounts.
                    </dd>
                  </div>
                  <div className="sm:col-span-1">
                    <dt className="text-sm font-medium text-gray-500">Cash Price</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      The discounted price offered to patients who pay without insurance.
                    </dd>
                  </div>
                  <div className="sm:col-span-1">
                    <dt className="text-sm font-medium text-gray-500">Min Negotiated</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      The lowest rate negotiated with insurance companies.
                    </dd>
                  </div>
                  <div className="sm:col-span-1">
                    <dt className="text-sm font-medium text-gray-500">Max Negotiated</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      The highest rate negotiated with insurance companies.
                    </dd>
                  </div>
                </dl>
                <div className="mt-6 prose prose-blue text-sm text-gray-500">
                  <p>
                    <strong>Note:</strong> These prices represent the hospital's charges and may not reflect your actual out-of-pocket costs, which depend on your specific insurance coverage.
                  </p>
                  <p>
                    Always consult with your healthcare provider and insurance company for the most accurate cost estimates.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
      
      <footer className="bg-gray-800 text-white mt-12">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold">HealthcarePriceCompare</h3>
              <p className="mt-2 text-sm text-gray-300">
                Helping consumers make informed healthcare decisions through price transparency.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold">Resources</h3>
              <ul className="mt-2 space-y-2">
                <li>
                  <Link href="/about" className="text-sm text-gray-300 hover:text-white">About Us</Link>
                </li>
                <li>
                  <Link href="/faq" className="text-sm text-gray-300 hover:text-white">FAQ</Link>
                </li>
                <li>
                  <Link href="/privacy" className="text-sm text-gray-300 hover:text-white">Privacy Policy</Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold">Legal</h3>
              <p className="mt-2 text-sm text-gray-300">
                This application uses hospital price transparency data as required by the Centers for Medicare & Medicaid Services (CMS).
              </p>
            </div>
          </div>
          <div className="mt-8 border-t border-gray-700 pt-8 text-center">
            <p className="text-sm text-gray-300">
              &copy; {new Date().getFullYear()} HealthcarePriceCompare. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
