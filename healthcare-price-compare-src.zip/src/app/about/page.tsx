'use client';

import Link from 'next/link';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold text-blue-800">HealthcarePriceCompare</Link>
          <nav className="flex space-x-4">
            <Link href="/" className="text-blue-600 hover:text-blue-800">Home</Link>
            <Link href="/search" className="text-blue-600 hover:text-blue-800">Search</Link>
            <Link href="/faq" className="text-blue-600 hover:text-blue-800">FAQ</Link>
          </nav>
        </div>
      </header>
      
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="bg-white shadow overflow-hidden sm:rounded-lg">
          <div className="px-4 py-5 sm:px-6">
            <h1 className="text-3xl font-bold text-gray-900">About HealthcarePriceCompare</h1>
            <p className="mt-1 max-w-2xl text-sm text-gray-500">
              Empowering consumers with healthcare price transparency
            </p>
          </div>
          
          <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
            <div className="prose prose-blue max-w-none">
              <h2>Our Mission</h2>
              <p>
                HealthcarePriceCompare was created to help consumers make informed decisions about their healthcare by providing 
                transparent pricing information. We believe that everyone deserves to know the cost of medical procedures before 
                receiving care, allowing them to compare prices and find the best value for their healthcare needs.
              </p>
              
              <h2>Hospital Price Transparency</h2>
              <p>
                In January 2021, the Centers for Medicare & Medicaid Services (CMS) implemented a hospital price transparency rule 
                requiring hospitals to provide clear, accessible pricing information online about the items and services they provide. 
                This includes:
              </p>
              <ul>
                <li>A comprehensive machine-readable file with all items and services</li>
                <li>A consumer-friendly display of shoppable services</li>
              </ul>
              <p>
                HealthcarePriceCompare leverages this publicly available data to create a user-friendly platform where consumers 
                can easily search, compare, and understand healthcare prices across different hospitals.
              </p>
              
              <h2>How We Help</h2>
              <p>Our platform offers several key benefits:</p>
              <ul>
                <li><strong>Price Comparison:</strong> Compare prices for the same procedure across multiple hospitals</li>
                <li><strong>Location-Based Search:</strong> Find healthcare providers in your area</li>
                <li><strong>Comprehensive Information:</strong> View different price points including standard charges, cash prices, and negotiated rates</li>
                <li><strong>User-Friendly Interface:</strong> Easily navigate and understand complex healthcare pricing information</li>
              </ul>
              
              <h2>Understanding Healthcare Prices</h2>
              <p>
                Healthcare pricing can be complex. Here's what the different price types mean:
              </p>
              <ul>
                <li><strong>Standard Charge (Gross Charge):</strong> The hospital's full list price for an item or service, before any discounts</li>
                <li><strong>Discounted Cash Price:</strong> The price offered to patients who pay without using insurance</li>
                <li><strong>Negotiated Rates:</strong> The prices that hospitals have negotiated with insurance companies</li>
                <li><strong>Min/Max Negotiated Rates:</strong> The range of prices negotiated with different insurers (de-identified)</li>
              </ul>
              
              <h2>Data Sources</h2>
              <p>
                Our data comes directly from hospital price transparency machine-readable files as required by CMS regulations. 
                We regularly update our database to ensure the most current pricing information is available.
              </p>
              
              <h2>Limitations</h2>
              <p>
                While we strive to provide accurate and comprehensive information, there are some limitations to be aware of:
              </p>
              <ul>
                <li>Prices shown are hospital charges and may not reflect your actual out-of-pocket costs</li>
                <li>Your specific insurance plan's coverage, deductibles, and co-pays will affect your final cost</li>
                <li>Not all hospitals comply fully with price transparency requirements, resulting in data gaps</li>
                <li>Price is just one factor to consider when choosing healthcare providers; quality, expertise, and convenience are also important</li>
              </ul>
              
              <h2>Contact Us</h2>
              <p>
                We welcome your feedback and questions. Please contact us at <a href="mailto:info@healthcarepricecompare.org" className="text-blue-600 hover:text-blue-800">info@healthcarepricecompare.org</a>.
              </p>
            </div>
          </div>
        </div>
      </main>
      
      <footer className="bg-gray-800 text-white mt-12">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold">HealthcarePriceCompare</h3>
              <p className="mt-2 text-sm text-gray-300">
                Helping consumers make informed healthcare decisions through price transparency.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold">Resources</h3>
              <ul className="mt-2 space-y-2">
                <li>
                  <Link href="/about" className="text-sm text-gray-300 hover:text-white">About Us</Link>
                </li>
                <li>
                  <Link href="/faq" className="text-sm text-gray-300 hover:text-white">FAQ</Link>
                </li>
                <li>
                  <Link href="/privacy" className="text-sm text-gray-300 hover:text-white">Privacy Policy</Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold">Legal</h3>
              <p className="mt-2 text-sm text-gray-300">
                This application uses hospital price transparency data as required by the Centers for Medicare & Medicaid Services (CMS).
              </p>
            </div>
          </div>
          <div className="mt-8 border-t border-gray-700 pt-8 text-center">
            <p className="text-sm text-gray-300">
              &copy; {new Date().getFullYear()} HealthcarePriceCompare. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
