import { NextRequest } from 'next/server';
import { compareProcedurePrices } from '@/lib/db/queries';

export const runtime = 'edge';

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const codeId = searchParams.get('code_id');
  const hospitalIds = searchParams.getAll('hospital_id');

  if (!codeId) {
    return Response.json({ 
      success: false, 
      error: 'Procedure code is required' 
    }, { status: 400 });
  }

  if (!hospitalIds.length) {
    return Response.json({ 
      success: false, 
      error: 'At least one hospital ID is required' 
    }, { status: 400 });
  }

  try {
    // @ts-ignore - DB is injected by Cloudflare Workers
    const comparisonData = await compareProcedurePrices(DB, codeId, hospitalIds);
    
    return Response.json({ 
      success: true, 
      data: comparisonData 
    });
  } catch (error) {
    console.error('Error comparing procedure prices:', error);
    return Response.json({ 
      success: false, 
      error: 'Failed to compare procedure prices' 
    }, { status: 500 });
  }
}
