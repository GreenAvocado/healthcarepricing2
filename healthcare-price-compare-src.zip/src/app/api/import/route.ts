import { NextRequest } from 'next/server';
import { importHospitalsFromCSV, importProcedureCodesFromCSV, importProcedurePricesFromCSV } from '@/lib/db/import';

export const runtime = 'edge';

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const fileType = formData.get('type') as string;
    const file = formData.get('file') as File;
    
    if (!file || !fileType) {
      return Response.json({ 
        success: false, 
        error: 'File and type are required' 
      }, { status: 400 });
    }
    
    const csvData = await file.text();
    let result;
    
    // @ts-ignore - DB is injected by Cloudflare Workers
    switch (fileType) {
      case 'hospitals':
        result = await importHospitalsFromCSV(DB, csvData);
        break;
      case 'procedures':
        result = await importProcedureCodesFromCSV(DB, csvData);
        break;
      case 'prices':
        result = await importProcedurePricesFromCSV(DB, csvData);
        break;
      default:
        return Response.json({ 
          success: false, 
          error: 'Invalid file type. Must be one of: hospitals, procedures, prices' 
        }, { status: 400 });
    }
    
    return Response.json({ 
      success: result.success, 
      data: { 
        count: result.count,
        errors: result.errors.length > 0 ? result.errors : undefined
      }
    });
  } catch (error) {
    console.error('Error importing data:', error);
    return Response.json({ 
      success: false, 
      error: 'Failed to import data' 
    }, { status: 500 });
  }
}
