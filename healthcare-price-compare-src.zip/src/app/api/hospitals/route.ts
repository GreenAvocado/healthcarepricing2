import { NextRequest } from 'next/server';
import { searchHospitals } from '@/lib/db/queries';

export const runtime = 'edge';

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const query = searchParams.get('query') || '';
  const state = searchParams.get('state') || undefined;
  const limit = parseInt(searchParams.get('limit') || '20', 10);

  try {
    // @ts-ignore - DB is injected by Cloudflare Workers
    const hospitals = await searchHospitals(DB, query, state, limit);
    
    return Response.json({ 
      success: true, 
      data: hospitals 
    });
  } catch (error) {
    console.error('Error searching hospitals:', error);
    return Response.json({ 
      success: false, 
      error: 'Failed to search hospitals' 
    }, { status: 500 });
  }
}
