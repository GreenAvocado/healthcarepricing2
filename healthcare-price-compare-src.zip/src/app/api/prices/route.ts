import { NextRequest } from 'next/server';
import { getProcedurePrices } from '@/lib/db/queries';

export const runtime = 'edge';

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const codeId = searchParams.get('code_id');
  const zipCode = searchParams.get('zip_code') || undefined;
  const radius = parseInt(searchParams.get('radius') || '50', 10);
  const limit = parseInt(searchParams.get('limit') || '20', 10);

  if (!codeId) {
    return Response.json({ 
      success: false, 
      error: 'Procedure code is required' 
    }, { status: 400 });
  }

  try {
    // @ts-ignore - DB is injected by Cloudflare Workers
    const prices = await getProcedurePrices(DB, codeId, zipCode, radius, limit);
    
    return Response.json({ 
      success: true, 
      data: prices 
    });
  } catch (error) {
    console.error('Error getting procedure prices:', error);
    return Response.json({ 
      success: false, 
      error: 'Failed to get procedure prices' 
    }, { status: 500 });
  }
}
