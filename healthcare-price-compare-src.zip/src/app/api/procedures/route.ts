import { NextRequest } from 'next/server';
import { searchProcedures } from '@/lib/db/queries';

export const runtime = 'edge';

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const query = searchParams.get('query') || '';
  const codeType = searchParams.get('type') || undefined;
  const limit = parseInt(searchParams.get('limit') || '20', 10);

  try {
    // @ts-ignore - DB is injected by Cloudflare Workers
    const procedures = await searchProcedures(DB, query, codeType, limit);
    
    return Response.json({ 
      success: true, 
      data: procedures 
    });
  } catch (error) {
    console.error('Error searching procedures:', error);
    return Response.json({ 
      success: false, 
      error: 'Failed to search procedures' 
    }, { status: 500 });
  }
}
