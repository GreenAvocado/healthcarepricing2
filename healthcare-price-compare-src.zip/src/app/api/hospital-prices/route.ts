import { NextRequest } from 'next/server';
import { getHospitalProcedurePrices } from '@/lib/db/queries';

export const runtime = 'edge';

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const hospitalId = searchParams.get('hospital_id');
  const limit = parseInt(searchParams.get('limit') || '50', 10);

  if (!hospitalId) {
    return Response.json({ 
      success: false, 
      error: 'Hospital ID is required' 
    }, { status: 400 });
  }

  try {
    // @ts-ignore - DB is injected by Cloudflare Workers
    const prices = await getHospitalProcedurePrices(DB, hospitalId, limit);
    
    return Response.json({ 
      success: true, 
      data: prices 
    });
  } catch (error) {
    console.error('Error getting hospital procedure prices:', error);
    return Response.json({ 
      success: false, 
      error: 'Failed to get hospital procedure prices' 
    }, { status: 500 });
  }
}
