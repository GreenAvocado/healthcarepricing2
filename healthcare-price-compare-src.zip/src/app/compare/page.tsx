'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

interface ProcedurePrice {
  price_id?: number;
  hospital_id: string;
  code_id: string;
  hospital_name: string;
  setting?: string;
  gross_charge?: number;
  discounted_cash_price?: number;
  min_negotiated_charge?: number;
  max_negotiated_charge?: number;
}

export default function ComparePage() {
  const [procedureCode, setProcedureCode] = useState<string>('');
  const [hospitalIds, setHospitalIds] = useState<string[]>([]);
  const [procedureDetails, setProcedureDetails] = useState<any>(null);
  const [comparisonData, setComparisonData] = useState<ProcedurePrice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  useEffect(() => {
    // Get parameters from URL
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    const hospitals = urlParams.getAll('hospital');
    
    if (code) {
      setProcedureCode(code);
    }
    
    if (hospitals.length) {
      setHospitalIds(hospitals);
    }
    
    if (code && hospitals.length) {
      loadComparisonData(code, hospitals);
    } else {
      setError('Missing required parameters: procedure code and at least two hospitals');
      setLoading(false);
    }
  }, []);
  
  const loadComparisonData = async (code: string, hospitals: string[]) => {
    setLoading(true);
    setError('');
    
    try {
      // Get procedure details
      const procedureResponse = await fetch(`/api/procedures?code_id=${code}`);
      const procedureData = await procedureResponse.json();
      
      if (procedureData.success && procedureData.data.length > 0) {
        setProcedureDetails(procedureData.data[0]);
      }
      
      // Get comparison data
      const params = new URLSearchParams();
      params.append('code_id', code);
      hospitals.forEach(id => params.append('hospital_id', id));
      
      const comparisonResponse = await fetch(`/api/compare?${params.toString()}`);
      const comparisonResult = await comparisonResponse.json();
      
      if (comparisonResult.success) {
        setComparisonData(comparisonResult.data);
      } else {
        setError(comparisonResult.error || 'Failed to load comparison data');
      }
    } catch (err) {
      setError('An error occurred while loading comparison data');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  const formatCurrency = (amount?: number) => {
    if (amount === undefined || amount === null) return 'N/A';
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };
  
  const getLowestPrice = (field: keyof ProcedurePrice): ProcedurePrice | null => {
    if (!comparisonData.length) return null;
    
    return comparisonData.reduce((lowest, current) => {
      if (current[field] === undefined || current[field] === null) return lowest;
      if (lowest === null) return current;
      if ((current[field] as number) < (lowest[field] as number)) return current;
      return lowest;
    }, null as ProcedurePrice | null);
  };
  
  const lowestCashPrice = getLowestPrice('discounted_cash_price');
  const lowestMinNegotiated = getLowestPrice('min_negotiated_charge');
  
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold text-blue-800">HealthcarePriceCompare</Link>
          <nav className="flex space-x-4">
            <Link href="/" className="text-blue-600 hover:text-blue-800">Home</Link>
            <Link href="/search" className="text-blue-600 hover:text-blue-800">Search</Link>
            <Link href="/about" className="text-blue-600 hover:text-blue-800">About</Link>
          </nav>
        </div>
      </header>
      
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {loading ? (
          <div className="text-center py-12">
            <svg className="animate-spin h-8 w-8 text-blue-500 mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            <p className="mt-2 text-sm text-gray-500">Loading comparison data...</p>
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <p className="text-red-500">{error}</p>
            <Link href="/search" className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700">
              Back to Search
            </Link>
          </div>
        ) : (
          <div>
            <div className="bg-white shadow overflow-hidden sm:rounded-lg mb-8">
              <div className="px-4 py-5 sm:px-6">
                <h2 className="text-2xl font-bold text-gray-900">
                  Price Comparison: {procedureDetails?.description || `Procedure ${procedureCode}`}
                </h2>
                <p className="mt-1 max-w-2xl text-sm text-gray-500">
                  Code: {procedureCode} | Type: {procedureDetails?.code_type || 'Unknown'}
                  {procedureDetails?.category && ` | Category: ${procedureDetails.category}`}
                </p>
              </div>
              
              {comparisonData.length === 0 ? (
                <div className="border-t border-gray-200 px-4 py-5 sm:px-6 text-center">
                  <p className="text-gray-500">No comparison data available for the selected hospitals and procedure.</p>
                  <Link href={`/procedure/${procedureCode}`} className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700">
                    Back to Procedure
                  </Link>
                </div>
              ) : (
                <div className="border-t border-gray-200">
                  {/* Price summary cards */}
                  <div className="px-4 py-5 sm:px-6">
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Price Summary</h3>
                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                      <div className="bg-blue-50 overflow-hidden shadow rounded-lg">
                        <div className="px-4 py-5 sm:p-6">
                          <dt className="text-sm font-medium text-gray-500 truncate">
                            Price Range (Cash Price)
                          </dt>
                          <dd className="mt-1 text-3xl font-semibold text-gray-900">
                            {formatCurrency(Math.min(...comparisonData.filter(d => d.discounted_cash_price !== undefined && d.discounted_cash_price !== null).map(d => d.discounted_cash_price as number)))} - 
                            {formatCurrency(Math.max(...comparisonData.filter(d => d.discounted_cash_price !== undefined && d.discounted_cash_price !== null).map(d => d.discounted_cash_price as number)))}
                          </dd>
                        </div>
                      </div>
                      
                      <div className="bg-green-50 overflow-hidden shadow rounded-lg">
                        <div className="px-4 py-5 sm:p-6">
                          <dt className="text-sm font-medium text-gray-500 truncate">
                            Lowest Cash Price
                          </dt>
                          <dd className="mt-1 text-3xl font-semibold text-gray-900">
                            {lowestCashPrice ? formatCurrency(lowestCashPrice.discounted_cash_price) : 'N/A'}
                          </dd>
                          {lowestCashPrice && (
                            <p className="mt-2 text-sm text-gray-500">
                              at {lowestCashPrice.hospital_name}
                            </p>
                          )}
                        </div>
                      </div>
                      
                      <div className="bg-purple-50 overflow-hidden shadow rounded-lg">
                        <div className="px-4 py-5 sm:p-6">
                          <dt className="text-sm font-medium text-gray-500 truncate">
                            Lowest Insurance Rate
                          </dt>
                          <dd className="mt-1 text-3xl font-semibold text-gray-900">
                            {lowestMinNegotiated ? formatCurrency(lowestMinNegotiated.min_negotiated_charge) : 'N/A'}
                          </dd>
                          {lowestMinNegotiated && (
                            <p className="mt-2 text-sm text-gray-500">
                              at {lowestMinNegotiated.hospital_name}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Detailed comparison table */}
                  <div className="px-4 py-5 sm:px-6">
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Detailed Comparison</h3>
                    <div className="flex flex-col">
                      <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                          <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                            <table className="min-w-full divide-y divide-gray-200">
                              <thead className="bg-gray-50">
                                <tr>
                                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Hospital
                                  </th>
                                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Standard Charge
                                  </th>
                                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Cash Price
                                  </th>
                                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Min Negotiated
                                  </th>
                                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Max Negotiated
                                  </th>
                                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Savings vs Highest
                                  </th>
                                </tr>
                              </thead>
                              <tbody className="bg-white divide-y divide-gray-200">
                                {comparisonData.map((price) => {
                                  // Calculate savings compared to highest price
                                  const highestCashPrice = Math.max(...comparisonData.filter(d => d.discounted_cash_price !== undefined && d.discounted_cash_price !== null).map(d => d.discounted_cash_price as number));
                                  const savings = price.discounted_cash_price !== undefined && price.discounted_cash_price !== null ? 
                                    highestCashPrice - price.discounted_cash_price : undefined;
                                  
                                  // Determine if this is the lowest price
                                  const isLowestPrice = lowestCashPrice && price.hospital_id === lowestCashPrice.hospital_id;
                                  
                                  return (
                                    <tr key={`${price.hospital_id}-${price.code_id}`} className={isLowestPrice ? 'bg-green-50' : ''}>
                                      <td className="px-6 py-4 whitespace-nowrap">
                                        <Link href={`/hospital/${price.hospital_id}`} className="text-blue-600 hover:text-blue-900">
                                          {price.hospital_name}
                                        </Link>
                                        {isLowestPrice && (
                                          <span className="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                            Lowest Price
                                          </span>
                                        )}
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {formatCurrency(price.gross_charge)}
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                        {formatCurrency(price.discounted_cash_price)}
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {formatCurrency(price.min_negotiated_charge)}
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {formatCurrency(price.max_negotiated_charge)}
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                        {savings !== undefined && savings > 0 ? (
                                          <span className="text-green-600">
                                            {formatCurrency(savings)} ({Math.round((savings / highestCashPrice) * 100)}%)
                                          </span>
                                        ) : (
                                          <span>-</span>
                                        )}
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="bg-white shadow overflow-hidden sm:rounded-lg">
              <div className="px-4 py-5 sm:px-6">
                <h3 className="text-lg font-medium text-gray-900">Understanding Price Differences</h3>
              </div>
              <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
                <div className="prose prose-blue max-w-none text-gray-500">
                  <p>
                    <strong>Why do prices vary between hospitals?</strong> Healthcare prices can vary significantly between hospitals due to factors such as:
                  </p>
                  <ul>
                    <li>Different operating costs and overhead expenses</li>
                    <li>Varying levels of charity care provided</li>
                    <li>Regional cost of living differences</li>
                    <li>Hospital size, type (teaching vs. community), and specialization</li>
                    <li>Negotiating power with insurance companies</li>
                  </ul>
                  <p>
                    <strong>What should I consider besides price?</strong> While price is important, also consider:
                  </p>
                  <ul>
                    <li>Quality metrics and patient outcomes</li>
                    <li>Hospital reputation and specialization</li>
                    <li>Distance and convenience</li>
                    <li>Your insurance network status</li>
                    <li>Your doctor's hospital privileges</li>
                  </ul>
                  <p>
                    <strong>Note:</strong> These prices represent the hospital's charges and may not reflect your actual out-of-pocket costs, which depend on your specific insurance coverage.
                    Always consult with your healthcare provider and insurance company for the most accurate cost estimates.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
      
      <footer className="bg-gray-800 text-white mt-12">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold">HealthcarePriceCompare</h3>
              <p className="mt-2 text-sm text-gray-300">
                Helping consumers make informed healthcare decisions through price transparency.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold">Resources</h3>
              <ul className="mt-2 space-y-2">
                <li>
                  <Link href="/about" className="text-sm text-gray-300 hover:text-white">About Us</Link>
                </li>
                <li>
                  <Link href="/faq" className="text-sm text-gray-300 hover:text-white">FAQ</Link>
                </li>
                <li>
                  <Link href="/privacy" className="text-sm text-gray-300 hover:text-white">Privacy Policy</Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold">Legal</h3>
              <p className="mt-2 text-sm text-gray-300">
                This application uses hospital price transparency data as required by the Centers for Medicare & Medicaid Services (CMS).
              </p>
            </div>
          </div>
          <div className="mt-8 border-t border-gray-700 pt-8 text-center">
            <p className="text-sm text-gray-300">
              &copy; {new Date().getFullYear()} HealthcarePriceCompare. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
