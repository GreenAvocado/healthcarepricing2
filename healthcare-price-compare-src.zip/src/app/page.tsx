'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Home() {
  const [zipCode, setZipCode] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-800">HealthcarePriceCompare</h1>
          <nav className="flex space-x-4">
            <Link href="/" className="text-blue-600 hover:text-blue-800">Home</Link>
            <Link href="/about" className="text-blue-600 hover:text-blue-800">About</Link>
            <Link href="/faq" className="text-blue-600 hover:text-blue-800">FAQ</Link>
          </nav>
        </div>
      </header>
      
      <main>
        {/* Hero Section */}
        <div className="bg-blue-700 text-white">
          <div className="max-w-7xl mx-auto px-4 py-16 sm:px-6 lg:px-8 text-center">
            <h2 className="text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl">
              Compare Healthcare Prices
            </h2>
            <p className="mt-6 text-xl max-w-3xl mx-auto">
              Find and compare prices for medical procedures at hospitals across the United States.
              Make informed decisions about your healthcare.
            </p>
            
            <div className="mt-10 max-w-xl mx-auto">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <input
                    type="text"
                    placeholder="Enter ZIP code"
                    className="w-full px-5 py-3 border border-transparent rounded-md text-gray-900"
                    value={zipCode}
                    onChange={(e) => setZipCode(e.target.value)}
                  />
                </div>
                <div className="flex-1">
                  <input
                    type="text"
                    placeholder="Search procedures (e.g., MRI, colonoscopy)"
                    className="w-full px-5 py-3 border border-transparent rounded-md text-gray-900"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <div>
                  <Link 
                    href={`/search?zip=${zipCode}&query=${searchQuery}`}
                    className="w-full flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-500 hover:bg-blue-600"
                  >
                    Search
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Features Section */}
        <div className="py-12 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2 className="text-3xl font-extrabold text-gray-900">
                Why Use HealthcarePriceCompare?
              </h2>
            </div>
            
            <div className="mt-10">
              <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-3">
                <div className="text-center">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white mx-auto">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="h-6 w-6">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                  </div>
                  <h3 className="mt-4 text-lg font-medium text-gray-900">Transparent Pricing</h3>
                  <p className="mt-2 text-base text-gray-500">
                    Access real hospital pricing data required by CMS transparency regulations.
                  </p>
                </div>
                
                <div className="text-center">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white mx-auto">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="h-6 w-6">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
                    </svg>
                  </div>
                  <h3 className="mt-4 text-lg font-medium text-gray-900">Compare Costs</h3>
                  <p className="mt-2 text-base text-gray-500">
                    Easily compare prices for the same procedure across different hospitals.
                  </p>
                </div>
                
                <div className="text-center">
                  <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-500 text-white mx-auto">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" className="h-6 w-6">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                  </div>
                  <h3 className="mt-4 text-lg font-medium text-gray-900">Find Nearby Options</h3>
                  <p className="mt-2 text-base text-gray-500">
                    Discover affordable healthcare options in your local area.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Common Procedures Section */}
        <div className="py-12 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h2 className="text-3xl font-extrabold text-gray-900">
                Common Procedures
              </h2>
              <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
                Start by exploring prices for these frequently searched procedures
              </p>
            </div>
            
            <div className="mt-10">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {[
                  { name: 'MRI', code: '73721', description: 'Magnetic Resonance Imaging' },
                  { name: 'CT Scan', code: '70450', description: 'Computed Tomography' },
                  { name: 'Colonoscopy', code: '45378', description: 'Diagnostic Colonoscopy' },
                  { name: 'Joint Replacement', code: '470', description: 'Major Joint Replacement (DRG)' },
                  { name: 'Childbirth', code: '59400', description: 'Routine Obstetric Care' },
                  { name: 'Physical Therapy', code: '97110', description: 'Therapeutic Exercises' },
                ].map((procedure) => (
                  <Link 
                    key={procedure.code}
                    href={`/procedure/${procedure.code}`}
                    className="relative rounded-lg border border-gray-300 bg-white px-6 py-5 shadow-sm flex items-center space-x-3 hover:border-blue-400 hover:bg-blue-50"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-lg font-medium text-gray-900">{procedure.name}</p>
                      <p className="text-sm text-gray-500 truncate">{procedure.description}</p>
                      <p className="text-xs text-gray-400">Code: {procedure.code}</p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <footer className="bg-gray-800 text-white">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold">HealthcarePriceCompare</h3>
              <p className="mt-2 text-sm text-gray-300">
                Helping consumers make informed healthcare decisions through price transparency.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold">Resources</h3>
              <ul className="mt-2 space-y-2">
                <li>
                  <Link href="/about" className="text-sm text-gray-300 hover:text-white">About Us</Link>
                </li>
                <li>
                  <Link href="/faq" className="text-sm text-gray-300 hover:text-white">FAQ</Link>
                </li>
                <li>
                  <Link href="/privacy" className="text-sm text-gray-300 hover:text-white">Privacy Policy</Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold">Legal</h3>
              <p className="mt-2 text-sm text-gray-300">
                This application uses hospital price transparency data as required by the Centers for Medicare & Medicaid Services (CMS).
              </p>
            </div>
          </div>
          <div className="mt-8 border-t border-gray-700 pt-8 text-center">
            <p className="text-sm text-gray-300">
              &copy; {new Date().getFullYear()} HealthcarePriceCompare. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
