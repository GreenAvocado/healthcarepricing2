'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

interface SearchParams {
  zip?: string;
  query?: string;
}

interface Procedure {
  code_id: string;
  description: string;
  code_type: string;
  category?: string;
}

interface Hospital {
  hospital_id: string;
  legal_name: string;
  common_name?: string;
  city?: string;
  state?: string;
  zip_code?: string;
}

export default function SearchPage({ 
  searchParams 
}: { 
  searchParams: SearchParams 
}) {
  const [zipCode, setZipCode] = useState(searchParams.zip || '');
  const [searchQuery, setSearchQuery] = useState(searchParams.query || '');
  const [activeTab, setActiveTab] = useState('procedures');
  
  const [procedures, setProcedures] = useState<Procedure[]>([]);
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Search when query or zip changes
  useEffect(() => {
    if (searchQuery) {
      performSearch();
    }
  }, []);

  const performSearch = async () => {
    if (!searchQuery) return;
    
    setLoading(true);
    setError('');
    
    try {
      if (activeTab === 'procedures') {
        const response = await fetch(`/api/procedures?query=${encodeURIComponent(searchQuery)}`);
        const data = await response.json();
        
        if (data.success) {
          setProcedures(data.data);
        } else {
          setError(data.error || 'Failed to search procedures');
        }
      } else {
        const params = new URLSearchParams();
        params.append('query', searchQuery);
        if (zipCode) {
          params.append('state', getStateFromZip(zipCode));
        }
        
        const response = await fetch(`/api/hospitals?${params.toString()}`);
        const data = await response.json();
        
        if (data.success) {
          setHospitals(data.data);
        } else {
          setError(data.error || 'Failed to search hospitals');
        }
      }
    } catch (err) {
      setError('An error occurred while searching');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Simple function to extract state from ZIP code
  // In a real app, this would use a ZIP code database
  const getStateFromZip = (zip: string): string => {
    const firstDigit = parseInt(zip.charAt(0), 10);
    
    // Very simplified mapping
    const stateMap: Record<number, string> = {
      0: 'CT', 1: 'NY', 2: 'PA', 3: 'FL', 
      4: 'GA', 5: 'MI', 6: 'IL', 7: 'TX',
      8: 'CO', 9: 'CA'
    };
    
    return stateMap[firstDigit] || '';
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    performSearch();
  };

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    if (searchQuery) {
      performSearch();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold text-blue-800">HealthcarePriceCompare</Link>
          <nav className="flex space-x-4">
            <Link href="/" className="text-blue-600 hover:text-blue-800">Home</Link>
            <Link href="/about" className="text-blue-600 hover:text-blue-800">About</Link>
            <Link href="/faq" className="text-blue-600 hover:text-blue-800">FAQ</Link>
          </nav>
        </div>
      </header>
      
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="bg-white shadow overflow-hidden sm:rounded-lg">
          <div className="px-4 py-5 sm:px-6">
            <h2 className="text-2xl font-bold text-gray-900">Search Healthcare Prices</h2>
            <p className="mt-1 max-w-2xl text-sm text-gray-500">
              Find procedures or hospitals to compare prices
            </p>
          </div>
          
          <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
            <form onSubmit={handleSearch} className="space-y-4">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <label htmlFor="search-query" className="block text-sm font-medium text-gray-700">
                    Search Term
                  </label>
                  <input
                    type="text"
                    id="search-query"
                    placeholder="Procedure name, code, or hospital name"
                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <div className="sm:w-1/4">
                  <label htmlFor="zip-code" className="block text-sm font-medium text-gray-700">
                    ZIP Code (Optional)
                  </label>
                  <input
                    type="text"
                    id="zip-code"
                    placeholder="Enter ZIP code"
                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    value={zipCode}
                    onChange={(e) => setZipCode(e.target.value)}
                  />
                </div>
                <div className="sm:flex-none sm:self-end">
                  <button
                    type="submit"
                    className="w-full inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Search
                  </button>
                </div>
              </div>
            </form>
            
            <div className="mt-6">
              <div className="sm:hidden">
                <select
                  className="block w-full rounded-md border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                  value={activeTab}
                  onChange={(e) => handleTabChange(e.target.value)}
                >
                  <option value="procedures">Procedures</option>
                  <option value="hospitals">Hospitals</option>
                </select>
              </div>
              <div className="hidden sm:block">
                <div className="border-b border-gray-200">
                  <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                    <button
                      onClick={() => handleTabChange('procedures')}
                      className={`${
                        activeTab === 'procedures'
                          ? 'border-blue-500 text-blue-600'
                          : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                      } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                    >
                      Procedures
                    </button>
                    <button
                      onClick={() => handleTabChange('hospitals')}
                      className={`${
                        activeTab === 'hospitals'
                          ? 'border-blue-500 text-blue-600'
                          : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                      } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                    >
                      Hospitals
                    </button>
                  </nav>
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              {loading ? (
                <div className="text-center py-12">
                  <svg className="animate-spin h-8 w-8 text-blue-500 mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  <p className="mt-2 text-sm text-gray-500">Loading results...</p>
                </div>
              ) : error ? (
                <div className="text-center py-12">
                  <p className="text-red-500">{error}</p>
                </div>
              ) : activeTab === 'procedures' ? (
                <div>
                  {procedures.length === 0 && searchQuery ? (
                    <p className="text-center py-12 text-gray-500">No procedures found matching "{searchQuery}"</p>
                  ) : (
                    <ul className="divide-y divide-gray-200">
                      {procedures.map((procedure) => (
                        <li key={procedure.code_id} className="py-4">
                          <Link 
                            href={`/procedure/${procedure.code_id}?zip=${zipCode}`}
                            className="block hover:bg-gray-50 transition duration-150 ease-in-out"
                          >
                            <div className="px-4 py-2 sm:px-6">
                              <div className="flex items-center justify-between">
                                <p className="text-lg font-medium text-blue-600 truncate">
                                  {procedure.description}
                                </p>
                                <div className="ml-2 flex-shrink-0 flex">
                                  <p className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                    {procedure.code_type}
                                  </p>
                                </div>
                              </div>
                              <div className="mt-2 flex justify-between">
                                <div className="sm:flex">
                                  <p className="flex items-center text-sm text-gray-500">
                                    Code: {procedure.code_id}
                                  </p>
                                  {procedure.category && (
                                    <p className="mt-2 flex items-center text-sm text-gray-500 sm:mt-0 sm:ml-6">
                                      Category: {procedure.category}
                                    </p>
                                  )}
                                </div>
                                <div className="text-sm text-gray-500">
                                  Click to view prices
                                </div>
                              </div>
                            </div>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ) : (
                <div>
                  {hospitals.length === 0 && searchQuery ? (
                    <p className="text-center py-12 text-gray-500">No hospitals found matching "{searchQuery}"</p>
                  ) : (
                    <ul className="divide-y divide-gray-200">
                      {hospitals.map((hospital) => (
                        <li key={hospital.hospital_id} className="py-4">
                          <Link 
                            href={`/hospital/${hospital.hospital_id}`}
                            className="block hover:bg-gray-50 transition duration-150 ease-in-out"
                          >
                            <div className="px-4 py-2 sm:px-6">
                              <div className="flex items-center justify-between">
                                <p className="text-lg font-medium text-blue-600 truncate">
                                  {hospital.common_name || hospital.legal_name}
                                </p>
                              </div>
                              <div className="mt-2 flex justify-between">
                                <div className="sm:flex">
                                  <p className="flex items-center text-sm text-gray-500">
                                    {hospital.city}, {hospital.state} {hospital.zip_code}
                                  </p>
                                </div>
                                <div className="text-sm text-gray-500">
                                  Click to view prices
                                </div>
                              </div>
                            </div>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      
      <footer className="bg-gray-800 text-white mt-12">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold">HealthcarePriceCompare</h3>
              <p className="mt-2 text-sm text-gray-300">
                Helping consumers make informed healthcare decisions through price transparency.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold">Resources</h3>
              <ul className="mt-2 space-y-2">
                <li>
                  <Link href="/about" className="text-sm text-gray-300 hover:text-white">About Us</Link>
                </li>
                <li>
                  <Link href="/faq" className="text-sm text-gray-300 hover:text-white">FAQ</Link>
                </li>
                <li>
                  <Link href="/privacy" className="text-sm text-gray-300 hover:text-white">Privacy Policy</Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold">Legal</h3>
              <p className="mt-2 text-sm text-gray-300">
                This application uses hospital price transparency data as required by the Centers for Medicare & Medicaid Services (CMS).
              </p>
            </div>
          </div>
          <div className="mt-8 border-t border-gray-700 pt-8 text-center">
            <p className="text-sm text-gray-300">
              &copy; {new Date().getFullYear()} HealthcarePriceCompare. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
