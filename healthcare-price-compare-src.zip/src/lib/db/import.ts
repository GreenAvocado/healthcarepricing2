// Data import utility functions

import { Hospital, ProcedureCode, ProcedurePrice } from './schema';
import { insertRecord } from './utils';
import { D1Database } from '@cloudflare/workers-types';

/**
 * Import hospital data from CSV file
 * Expected format: hospital_id,legal_name,common_name,address,city,state,zip_code,website_url,phone
 */
export async function importHospitalsFromCSV(
  db: D1Database,
  csvData: string
): Promise<{ success: boolean; count: number; errors: string[] }> {
  const lines = csvData.trim().split('\n');
  const headers = lines[0].split(',');
  
  let successCount = 0;
  const errors: string[] = [];
  
  // Process each line (skip header)
  for (let i = 1; i < lines.length; i++) {
    try {
      const values = lines[i].split(',');
      const hospital: Partial<Hospital> = {};
      
      // Map CSV columns to hospital properties
      headers.forEach((header, index) => {
        if (values[index]) {
          hospital[header as keyof Hospital] = values[index];
        }
      });
      
      // Ensure required fields
      if (!hospital.hospital_id || !hospital.legal_name) {
        errors.push(`Line ${i+1}: Missing required fields (hospital_id or legal_name)`);
        continue;
      }
      
      // Insert hospital record
      const result = await insertRecord(db, 'hospitals', hospital as Hospital);
      if (result !== null) {
        successCount++;
      } else {
        errors.push(`Line ${i+1}: Failed to insert hospital record`);
      }
    } catch (error) {
      errors.push(`Line ${i+1}: ${error}`);
    }
  }
  
  return {
    success: successCount > 0,
    count: successCount,
    errors
  };
}

/**
 * Import procedure codes from CSV file
 * Expected format: code_id,code_type,description,category,subcategory
 */
export async function importProcedureCodesFromCSV(
  db: D1Database,
  csvData: string
): Promise<{ success: boolean; count: number; errors: string[] }> {
  const lines = csvData.trim().split('\n');
  const headers = lines[0].split(',');
  
  let successCount = 0;
  const errors: string[] = [];
  
  // Process each line (skip header)
  for (let i = 1; i < lines.length; i++) {
    try {
      const values = lines[i].split(',');
      const procedureCode: Partial<ProcedureCode> = {};
      
      // Map CSV columns to procedure code properties
      headers.forEach((header, index) => {
        if (values[index]) {
          procedureCode[header as keyof ProcedureCode] = values[index];
        }
      });
      
      // Ensure required fields
      if (!procedureCode.code_id || !procedureCode.code_type || !procedureCode.description) {
        errors.push(`Line ${i+1}: Missing required fields (code_id, code_type, or description)`);
        continue;
      }
      
      // Insert procedure code record
      const result = await insertRecord(db, 'procedure_codes', procedureCode as ProcedureCode);
      if (result !== null) {
        successCount++;
      } else {
        errors.push(`Line ${i+1}: Failed to insert procedure code record`);
      }
    } catch (error) {
      errors.push(`Line ${i+1}: ${error}`);
    }
  }
  
  return {
    success: successCount > 0,
    count: successCount,
    errors
  };
}

/**
 * Import procedure prices from CSV file
 * Expected format: hospital_id,code_id,setting,gross_charge,discounted_cash_price,min_negotiated_charge,max_negotiated_charge
 */
export async function importProcedurePricesFromCSV(
  db: D1Database,
  csvData: string
): Promise<{ success: boolean; count: number; errors: string[] }> {
  const lines = csvData.trim().split('\n');
  const headers = lines[0].split(',');
  
  let successCount = 0;
  const errors: string[] = [];
  
  // Process each line (skip header)
  for (let i = 1; i < lines.length; i++) {
    try {
      const values = lines[i].split(',');
      const procedurePrice: Partial<ProcedurePrice> = {};
      
      // Map CSV columns to procedure price properties
      headers.forEach((header, index) => {
        if (values[index]) {
          // Convert numeric fields
          if (['gross_charge', 'discounted_cash_price', 'min_negotiated_charge', 'max_negotiated_charge'].includes(header)) {
            procedurePrice[header as keyof ProcedurePrice] = parseFloat(values[index]);
          } else {
            procedurePrice[header as keyof ProcedurePrice] = values[index];
          }
        }
      });
      
      // Ensure required fields
      if (!procedurePrice.hospital_id || !procedurePrice.code_id) {
        errors.push(`Line ${i+1}: Missing required fields (hospital_id or code_id)`);
        continue;
      }
      
      // Insert procedure price record
      const result = await insertRecord(db, 'procedure_prices', procedurePrice as ProcedurePrice);
      if (result !== null) {
        successCount++;
      } else {
        errors.push(`Line ${i+1}: Failed to insert procedure price record`);
      }
    } catch (error) {
      errors.push(`Line ${i+1}: ${error}`);
    }
  }
  
  return {
    success: successCount > 0,
    count: successCount,
    errors
  };
}
