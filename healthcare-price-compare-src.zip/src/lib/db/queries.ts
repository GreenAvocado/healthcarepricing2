import { Hospital, ProcedureCode, ProcedurePrice } from '@/lib/db/schema';
import { executeQuery } from '@/lib/db/utils';
import { D1Database } from '@cloudflare/workers-types';

export async function searchHospitals(
  db: D1Database,
  query: string,
  state?: string,
  limit: number = 20
): Promise<Hospital[]> {
  let sql = `
    SELECT * FROM hospitals 
    WHERE (legal_name LIKE ? OR common_name LIKE ?)
  `;
  
  const params: any[] = [`%${query}%`, `%${query}%`];
  
  if (state) {
    sql += ` AND state = ?`;
    params.push(state);
  }
  
  sql += ` LIMIT ?`;
  params.push(limit);
  
  return executeQuery<Hospital>(db, sql, params);
}

export async function searchProcedures(
  db: D1Database,
  query: string,
  codeType?: string,
  limit: number = 20
): Promise<ProcedureCode[]> {
  let sql = `
    SELECT * FROM procedure_codes 
    WHERE (code_id LIKE ? OR description LIKE ?)
  `;
  
  const params: any[] = [`%${query}%`, `%${query}%`];
  
  if (codeType) {
    sql += ` AND code_type = ?`;
    params.push(codeType);
  }
  
  sql += ` LIMIT ?`;
  params.push(limit);
  
  return executeQuery<ProcedureCode>(db, sql, params);
}

export async function getProcedurePrices(
  db: D1Database,
  codeId: string,
  zipCode?: string,
  radius: number = 50,
  limit: number = 20
): Promise<(ProcedurePrice & { hospital_name: string })[]> {
  let sql = `
    SELECT pp.*, h.legal_name as hospital_name
    FROM procedure_prices pp
    JOIN hospitals h ON pp.hospital_id = h.hospital_id
    WHERE pp.code_id = ?
  `;
  
  const params: any[] = [codeId];
  
  if (zipCode) {
    // In a real implementation, we would use geospatial queries
    // For now, we'll just filter by the first 3 digits of the ZIP code as a simple approximation
    const zipPrefix = zipCode.substring(0, 3);
    sql += ` AND h.zip_code LIKE ?`;
    params.push(`${zipPrefix}%`);
  }
  
  sql += ` ORDER BY pp.discounted_cash_price ASC LIMIT ?`;
  params.push(limit);
  
  return executeQuery<ProcedurePrice & { hospital_name: string }>(db, sql, params);
}

export async function getHospitalProcedurePrices(
  db: D1Database,
  hospitalId: string,
  limit: number = 50
): Promise<(ProcedurePrice & { procedure_name: string })[]> {
  const sql = `
    SELECT pp.*, pc.description as procedure_name
    FROM procedure_prices pp
    JOIN procedure_codes pc ON pp.code_id = pc.code_id
    WHERE pp.hospital_id = ?
    ORDER BY pp.code_id
    LIMIT ?
  `;
  
  return executeQuery<ProcedurePrice & { procedure_name: string }>(db, sql, [hospitalId, limit]);
}

export async function compareProcedurePrices(
  db: D1Database,
  codeId: string,
  hospitalIds: string[]
): Promise<(ProcedurePrice & { hospital_name: string })[]> {
  if (!hospitalIds.length) return [];
  
  const placeholders = hospitalIds.map(() => '?').join(',');
  const sql = `
    SELECT pp.*, h.legal_name as hospital_name
    FROM procedure_prices pp
    JOIN hospitals h ON pp.hospital_id = h.hospital_id
    WHERE pp.code_id = ? AND pp.hospital_id IN (${placeholders})
    ORDER BY pp.discounted_cash_price ASC
  `;
  
  return executeQuery<ProcedurePrice & { hospital_name: string }>(db, sql, [codeId, ...hospitalIds]);
}
