// Import script for sample hospital price data
// This script imports sample data into the database for testing and demonstration purposes

import { db } from './utils';
import { hospitals, procedures, prices } from './schema';

async function importSampleData() {
  console.log('Importing sample hospital data...');
  
  try {
    // Import sample hospitals
    const hospitalData = [
      {
        hospital_id: 'NYP001',
        legal_name: 'New York-Presbyterian Hospital',
        common_name: 'NY Presbyterian Hospital',
        city: 'New York',
        state: 'NY',
        zip_code: '10065'
      },
      {
        hospital_id: 'MSM001',
        legal_name: 'Mount Sinai Medical Center',
        common_name: 'Mount Sinai Medical Center',
        city: 'New York',
        state: 'NY',
        zip_code: '10029'
      },
      {
        hospital_id: 'NYU001',
        legal_name: 'NYU Langone Hospitals',
        common_name: 'NYU Langone Health',
        city: 'New York',
        state: 'NY',
        zip_code: '10016'
      },
      {
        hospital_id: 'MSK001',
        legal_name: 'Memorial Sloan Kettering Cancer Center',
        common_name: 'Memorial Sloan Kettering',
        city: 'New York',
        state: 'NY',
        zip_code: '10065'
      },
      {
        hospital_id: 'LHH001',
        legal_name: 'Lenox Hill Hospital',
        common_name: 'Lenox Hill Hospital',
        city: 'New York',
        state: 'NY',
        zip_code: '10075'
      }
    ];
    
    for (const hospital of hospitalData) {
      await db.insert(hospitals).values(hospital).run();
    }
    console.log(`Imported ${hospitalData.length} hospitals`);
    
    // Import sample procedures
    const procedureData = [
      {
        code_id: '70551',
        code_type: 'CPT',
        description: 'MRI - Brain without contrast',
        category: 'Diagnostic Imaging'
      },
      {
        code_id: '70552',
        code_type: 'CPT',
        description: 'MRI - Brain with contrast',
        category: 'Diagnostic Imaging'
      },
      {
        code_id: '72141',
        code_type: 'CPT',
        description: 'MRI - Cervical spine without contrast',
        category: 'Diagnostic Imaging'
      },
      {
        code_id: '72148',
        code_type: 'CPT',
        description: 'MRI - Lumbar spine without contrast',
        category: 'Diagnostic Imaging'
      },
      {
        code_id: '73721',
        code_type: 'CPT',
        description: 'MRI - Knee without contrast',
        category: 'Diagnostic Imaging'
      },
      {
        code_id: '71046',
        code_type: 'CPT',
        description: 'X-Ray - Chest, 2 views',
        category: 'Diagnostic Imaging'
      },
      {
        code_id: '74177',
        code_type: 'CPT',
        description: 'CT Scan - Abdomen with contrast',
        category: 'Diagnostic Imaging'
      },
      {
        code_id: '76700',
        code_type: 'CPT',
        description: 'Ultrasound - Abdomen complete',
        category: 'Diagnostic Imaging'
      },
      {
        code_id: '80053',
        code_type: 'CPT',
        description: 'Blood Test - Comprehensive panel',
        category: 'Laboratory'
      },
      {
        code_id: '99213',
        code_type: 'CPT',
        description: 'Office visit - Established patient, moderate complexity',
        category: 'Evaluation & Management'
      }
    ];
    
    for (const procedure of procedureData) {
      await db.insert(procedures).values(procedure).run();
    }
    console.log(`Imported ${procedureData.length} procedures`);
    
    // Generate price data for each hospital and procedure combination
    const priceData = [];
    
    // Helper function to generate random price within a range
    const randomPrice = (min, max) => Math.round(Math.random() * (max - min) + min);
    
    // For each hospital
    for (const hospital of hospitalData) {
      // For each procedure
      for (const procedure of procedureData) {
        // Generate base price
        const basePrice = randomPrice(
          procedure.code_id.startsWith('7') ? 1000 : 100,  // Imaging procedures are more expensive
          procedure.code_id.startsWith('7') ? 4000 : 800
        );
        
        // Calculate other prices based on the base price
        const cashPrice = Math.round(basePrice * 0.5);  // Cash price is typically 50% of standard charge
        const minNegotiated = Math.round(cashPrice * 0.6);  // Min negotiated is typically 60% of cash price
        const maxNegotiated = Math.round(basePrice * 0.7);  // Max negotiated is typically 70% of standard charge
        
        priceData.push({
          hospital_id: hospital.hospital_id,
          code_id: procedure.code_id,
          setting: 'Outpatient',
          gross_charge: basePrice,
          discounted_cash_price: cashPrice,
          min_negotiated_charge: minNegotiated,
          max_negotiated_charge: maxNegotiated
        });
      }
    }
    
    for (const price of priceData) {
      await db.insert(prices).values(price).run();
    }
    console.log(`Imported ${priceData.length} price records`);
    
    console.log('Sample data import completed successfully!');
    return { success: true, message: 'Sample data imported successfully' };
  } catch (error) {
    console.error('Error importing sample data:', error);
    return { success: false, error: error.message };
  }
}

export { importSampleData };
